mpegcd: sample data, losslessly compressed
==========================================

To restore the YUV files, open  https://lisa-vr.github.io/mpegcd/  and drop this .zip on it.
Everything runs in your browser; each restored file is checked against MD5SUMS.txt.

Data: ULB ToysTable (Bonatto, Fachada, Lafruit), CC BY-NC-SA, doi 10.5281/zenodo.5055542.
Three neighbouring cameras (plane B, y=325, x=370/404/438) are the 3 frames of each stream:
1920x1080 Kinect texture (yuv420p) and DERS depth (yuv420p16le). Nothing is resized or cropped.

The restored .yuv files are named <name>_<w>x<h>_<pix_fmt>.yuv, which YUView opens directly.
