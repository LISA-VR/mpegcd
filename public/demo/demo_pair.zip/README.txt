Real data from ULB ToysTable (Bonatto, Fachada, Lafruit), CC BY-NC-SA,
doi 10.5281/zenodo.5055542. Three neighbouring cameras (plane B, y=325, x=370/404/438)
are the 3 frames of each stream: 1920x1080 texture (8-bit) and DERS depth (16-bit).
Nothing is resized or cropped. Drop this zip on the page to restore the YUVs
and verify their MD5.
